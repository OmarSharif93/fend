# About
this project is about creating a landing page with a dynamic Navigation-bar by using javascript manipulating the DOM tree.

# What We Used
* Loops (for...of) (forEach)
* DOM object methods (document.querySelectorAll()) 
* documentFragment to enhance performance 
* IntersectionObserver Interface to change active class for the current section in the view port 
* events to interact with the users 


